<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">
          <div class="row">
            
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title"><?php echo e(__('keywords.Add Role')); ?></h4><br>
                             <?php if(count($errors) > 0): ?>
                              <?php if($errors->any()): ?>
                                <div class="alert alert-primary" role="alert">
                                  <?php echo e($errors->first()); ?>

                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                  </button>
                                </div>
                              <?php endif; ?>
                          <?php endif; ?>
                       
                  <form class="forms-sample" action="<?php echo e(route('addnewrole')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group">
                      <label for="exampleInputName1"><?php echo e(__('keywords.Role Name')); ?></label>
                      <input type="text" class="form-control" id="exampleInputName1" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('keywords.Role Name')); ?>">
                      </div>
                      <br>
                      
                    
                      <div class="form-group">
                   
                      
                      <h5 align="center"><b><?php echo e(__('keywords.Enable Sections')); ?></b> </h5><hr><br>
                    <div class="row">
                     <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                        
                          <input type="checkbox" form-control name="dashboard" value="1" >
                            &nbsp;&nbsp;<label><?php echo e(__('keywords.Dashboard')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                          
                          <input type="checkbox" form-control name="category" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Category')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                         
                          <input type="checkbox" form-control name="tax" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Tax')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                          <input type="checkbox" form-control name="id" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Id')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                          <input type="checkbox" form-control name="membership" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Membership')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                       
                          <input type="checkbox" form-control name="reports" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Reports')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                        
                          <input type="checkbox" form-control name="notification" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Notification')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                          
                          <input type="checkbox" form-control name="users" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Users')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                         
                          <input type="checkbox" form-control name="product" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Product')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                     
                          <input type="checkbox" form-control name="area" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Area')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                         
                          <input type="checkbox" form-control name="store" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Store')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                         
                          <input type="checkbox" form-control name="orders" value="1" > &nbsp;&nbsp;<label><?php echo e(__('keywords.Orders')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                          <input type="checkbox" form-control name="payout" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Payout')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                          
                          <input type="checkbox" form-control name="rewards" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Rewards')); ?></label><br>
                      </div>
                    </div>

                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                          <input type="checkbox" form-control name="delivery_boy" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Delivery Boy')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                       
                          <input type="checkbox" form-control name="pages" value="1" > &nbsp;&nbsp;<label><?php echo e(__('keywords.Pages')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                  
                          <input type="checkbox" form-control name="feedback" value="1" > &nbsp;&nbsp;<label><?php echo e(__('keywords.Feedback')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                        
                          <input type="checkbox" form-control name="callback" value="1" > &nbsp;&nbsp;<label><?php echo e(__('keywords.Callback')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                         
                          <input type="checkbox" form-control name="settings" value="1" > &nbsp;&nbsp;<label><?php echo e(__('keywords.Settings')); ?></label><br>
                      </div>
                    </div>
                    <div class="input-group col-xs-6 col-sm-6 col-md-4 col-lg-3">
                       <div class="form-group">
                          
                          <input type="checkbox" form-control name="reason" value="1" >&nbsp;&nbsp;<label><?php echo e(__('keywords.Cancelling Reasons')); ?></label><br>
                      </div>
                    </div>
        
                  </div>
                    
                    <button type="submit" class="btn btn-primary mr-2"><?php echo e(__('keywords.Submit')); ?></button>
                    <!--
                   
                    -->
                     <a href="<?php echo e(route('rolelist')); ?>" class="btn btn-danger"><?php echo e(__('keywords.Close')); ?></a>
                  </form>
                </div>
              </div>
            </div>
             <div class="col-md-2">
      </div>
     
          </div>
        </div>
        
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
          $(document).ready(function(){
          
                $(".des_price").hide();
                
            $(".img").on('change', function(){
                  $(".des_price").show();
              
          });
          });
</script>

 


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/sub/add.blade.php ENDPATH**/ ?>