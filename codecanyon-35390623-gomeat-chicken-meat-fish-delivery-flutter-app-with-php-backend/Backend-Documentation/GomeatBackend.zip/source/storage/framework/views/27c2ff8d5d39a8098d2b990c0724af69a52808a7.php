
<style>
 
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
      
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Store List(Waiting for approval)')); ?></h4>
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100 table-striped">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                     <th><?php echo e(__('keywords.Profile Pic')); ?></th>
                      <th><?php echo e(__('keywords.Store Name')); ?></th>
                      <th><?php echo e(__('keywords.City')); ?></th>
                      <th><?php echo e(__('keywords.Mobile')); ?></th>
                      <th><?php echo e(__('keywords.Email')); ?></th>
                      <th><?php echo e(__('keywords.Admin Share')); ?></th>
                      <th><?php echo e(__('keywords.Owner name')); ?></th>
                      <th><?php echo e(__('keywords.Details')); ?></th>
                    </thead>
                    <tbody>
                         <?php if(count($city)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                 <td><a href="<?php echo e($url_aws.$cities->store_photo); ?>"><img src="<?php echo e($url_aws.$cities->store_photo); ?>" style="width:50px;height:50px;border-radius:50%"  alt="image"></a></td>
                                <td><?php echo e($cities->store_name); ?></td>
                                <td><?php echo e($cities->city); ?></td>
                                <td><?php echo e($cities->phone_number); ?></td>
                                <td><?php echo e($cities->email); ?></td>
                                <td><?php echo e($cities->admin_share); ?> %</td>
                                <td><?php echo e($cities->employee_name); ?></td>
                                <td> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($cities->id); ?>"><?php echo e(__('keywords.Details')); ?></button>
                                </td>
                             
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td colspan="9"><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>
<br>
<div class="pull-right mb-1" style="float: right;">
  <?php echo e($city->render("pagination::bootstrap-4")); ?>

</div>
</div>
</div>
</div>
</div>
</div>
<div>
    </div>

    <script>  $(document).ready(function() {
  $('.image-link').magnificPopup({type:'image'});
});</script>

<?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
<div class="modal fade" id="exampleModal1<?php echo e($cities->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="container">
     
    	<div class="modal-dialog" role="document">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h5 class="modal-title" id="exampleModalLabel"><b><?php echo e($cities->store_name); ?> Profile</b> (<?php if($cities->store_status==1): ?>
                                   <span style="color:green"><b>Active</b></span>
                                    <?php else: ?>
                                   <span style="color:red"><b>Inactive</b></span>
                                    <?php endif; ?>)</h5>
    					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
    						<span aria-hidden="true">&times;</span>
    					</button>
    			</div>
        <div class="material-datatables">
              <form role="form" method="post" action="" >
            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%" data-background-color="purple">

                
                <tbody>
                    <tr>
                        <td colspan="3">
                            <table class="table">
                                <tr>
                                    <td valign="top" style="width:100%">
                                    <strong> <?php echo e(__('keywords.Store Name')); ?> : </strong> <?php echo e($cities->store_name); ?>

                                    <br />
                                      <strong><?php echo e(__('keywords.Owner Name')); ?> : </strong><?php echo e($cities->employee_name); ?><br/>
                                        <strong><?php echo e(__('keywords.Contact')); ?> : </strong><?php echo e($cities->phone_number); ?><br/> 
                                    <strong>  <?php echo e(__('keywords.Email')); ?> : </strong><?php echo e($cities->email); ?>

                                    <br />
                                    <strong>  <?php echo e(__('keywords.Time_Slot')); ?> : </strong><?php echo e($cities->store_opening_time); ?> - <?php echo e($cities->store_closing_time); ?>

                                    <br />
                                    <strong>  <?php echo e(__('keywords.Address')); ?> : </strong><?php echo e($cities->address); ?>

                                    <br />
                                     <strong> <?php echo e(__('keywords.Orders Per Time Slot')); ?> : </strong> <?php echo e($cities->orders); ?>

                                    <br />
                                      <strong><?php echo e(__('keywords.Admin Share')); ?> : </strong><?php echo e($cities->admin_share); ?> %<br/>
                                    </td>
                                   
                                    
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <th><?php echo e(__('keywords.ID')); ?></th>
                        <th><?php echo e(__('keywords.ID number')); ?></th>
                        <th><?php echo e(__('keywords.ID photo')); ?></th>
                    </tr>
                    <tr>
                        <td><?php echo e($cities->id_type); ?></td>
                        <td><?php echo e($cities->id_number); ?></td>
                        <td><a class="btn btn-default" href="<?php echo e($url_aws.$cities->id_photo); ?>">see ID photo</a></td>
                    </tr>
                           <tr>
                                    <td valign="top" style="width:50%; float:left;">
                                     <a href="<?php echo e(route('storeapproved', $cities->id)); ?>" button type="button" class="btn btn-success">
                                <?php echo e(__('keywords.Approve')); ?>

                                    </button></a>
                                     
                                    </td>
                                   <td valign="top" style="width:50%; float:right">
                                   <a href="<?php echo e(route('storedelete', $cities->id)); ?>" button type="button" class="btn btn-danger">
                                       <?php echo e(__('keywords.Delete')); ?>

                                    </button></a>
                                    </td>
                                    
                                </tr>
                   
                   
                </tbody>
            </table>
            </form>
        </div>
         <div class="modal-footer">
       <button class="btn btn-danger" data-dismiss="modal" aria-hidden="true"><?php echo e(__('keywords.Close')); ?></button>
      </div>
    </div>
    
    <!-- end content-->
</div></div>
                            <!--  end card  -->
	
		</div>
	</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/store/approval_wait.blade.php ENDPATH**/ ?>