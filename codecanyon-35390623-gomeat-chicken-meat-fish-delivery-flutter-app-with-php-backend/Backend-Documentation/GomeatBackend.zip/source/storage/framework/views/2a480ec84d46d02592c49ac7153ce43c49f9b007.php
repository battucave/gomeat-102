<?php $__env->startSection('content'); ?>
<div class="container-fluid">
          <div class="row">
               <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div>
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Add')); ?> <?php echo e(__('keywords.Secondary')); ?> <?php echo e(__('keywords.Banner')); ?></h4>
                  
                </div>
                <div class="card-body">
                  <form class="forms-sample" action="<?php echo e(route('sec_bannerupdate',$city->banner_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>


                    <div class="row">
                         <div class="container" align="center">
                         <img style="width:80px; height:80px; border-radius:50%" src="<?php echo e(url($city->banner_image)); ?>" />
                         </div>
                      <div class="col-md-12">
                          
                        <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Title')); ?></label>
                          <input type="text" name="banner" class="form-control" value="<?php echo e($city->banner_name); ?>">
                        </div>
                        <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                             <input type="hidden" name="old_image" value="<?php echo e($city->banner_image); ?>" >
                          <label class="bmd-label-floating"> <?php echo e(__('keywords.Image')); ?></label><br>
                          <label class="btn btn-default btn-sm center-block btn-file">
                              <i class="fa fa-upload fa-2x" aria-hidden="true"></i>
                              <input type="file" name="image" style="display: none;">
                            </label>
                        </div>
                      </div>
                    </div>
                    </div>
                   <div class="col-md-12">    
                      <div class="form-group">
                          <label class="bmd-label-floating"><?php echo e(__('keywords.Select')); ?> <?php echo e(__('keywords.Product')); ?></label>
                          <select name="varient_id" class="form-control">
                             
                              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		          	<option value="<?php echo e($categorys->varient_id); ?>" 
        		          	<?php if($city->varient_id == $categorys->varient_id): ?>selected <?php endif; ?>><?php echo e($categorys->product_name); ?> (<?php echo e($categorys->quantity); ?> <?php echo e($categorys->unit); ?>)</option>
        		              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                          </select>
                        </div>
                        </div>

                    <br>
                    

                    <button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>          
<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/store/banner/sec/banneredit.blade.php ENDPATH**/ ?>