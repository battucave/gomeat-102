

<style>
    .card-header.bg-primary.text-white {
    border-radius: 10px;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="row align-items-center">
        <!-- Page title actions -->
        <div class="col-auto ml-auto d-print-none">

        </div>
    </div>
</div>
<div class="row">
<div class="col-lg-12">
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
<?php if(is_array(session()->get('success'))): ?>
        <ul>
            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
            <?php echo e(session()->get('success')); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>
 <?php if(count($errors) > 0): ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e($errors->first()); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
  <?php endif; ?>
<?php endif; ?>
</div>
<div class="col-12">
<form method="post" class="validate" autocomplete="off" action="<?php echo e(route('bulk_upload')); ?>" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-6">
         <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                   <h5><?php echo e(__('keywords.Instructions')); ?></h5>
                </div>
                <div class="card-body">
                    <ol class="pl-3">
                      <li><?php echo e(__('keywords.Only CSV file are allowed')); ?>.</li>
                      <li><?php echo e(__('keywords.First row need to keep blank or use for column name only')); ?>.</li>
                      <li><?php echo e(__('keywords.All fields are must needed in csv file')); ?>.</li>
                      <li><?php echo e(__('keywords.fill the cat id(Which is available in Category list) od subcategory(which has a parent category) in category_id column of csv file')); ?>.</li>
                      <li><?php echo e(__('keywords.Insert tags in tags column separated by comma')); ?>.</li>
                      <li><?php echo e(__('keywords.Please upload the images on images/products path inside your main project directory')); ?>.</li>
                      <li><a style="color:blue" href="<?php echo e(asset('public/csv_sample/products.csv')); ?>" download="products.csv"><?php echo e(__('keywords.Download Sample File')); ?></a></li>
                   </ol>
                </div>
            </div>
        </div>  
            <div class="card">
                <div class="card-header bg-primary text-white">
                   <h5 class="panel-title"><?php echo e(__('keywords.Bulk Products Upload')); ?></h5>
                </div>
                <div class="card-body">
                    <?php echo e(csrf_field()); ?>


                    <div class="row">
                        <div class="col">
                            <div class="custom-file">
                            <input type="file" class="custom-file-input" id="customFile" name="select_file" data-allowed-file-extensions="csv" required/>
                            <label class="custom-file-label" for="customFile">Choose file</label>
                          </div>
                          
                            
                                                        
                        </div><br>

                  
                        <div class="col-md-12">
                           <br>
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-xs"><?php echo e(__('keywords.Import Products')); ?></button>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class="col-md-6">
         <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                   <h5><?php echo e(__('keywords.Instructions')); ?></h5>
                </div>
                <div class="card-body">
                   <ol class="pl-3">
                      <li><?php echo e(__('keywords.Only CSV file are allowed')); ?>.</li>
                      <li><?php echo e(__('keywords.First row need to keep blank or use for column name only')); ?>.</li>
                      <li><?php echo e(__('keywords.All fields are must needed in csv file')); ?>.</li>
                      <li><?php echo e(__('keywords.fill the product id(Which is available in product list) in product_id column of csv file')); ?>.</li>
                       <li><?php echo e(__('keywords.Insert tags in tags column separated by comma')); ?>.</li>
                      <li><a style="color:blue" href="<?php echo e(asset('public/csv_sample/productsvarient.csv')); ?>"  download="products_varient.csv"><?php echo e(__('keywords.Download Sample File')); ?></a></li>
                   </ol>
                </div>
            </div>
        </div>  
    <form method="post" class="validate" autocomplete="off" action="<?php echo e(route('bulk_v_upload')); ?>"  action="#" enctype="multipart/form-data">
        
            <div class="card">
                <?php echo e(csrf_field()); ?>

                <div class="card-header bg-primary text-white">
                   <h5 class="panel-title"><?php echo e(__('keywords.Bulk Varient Upload')); ?></h5>
                </div>
                <div class="card-body">

                    <div class="col">
                            
                             <div class="custom-file">
                            <input type="file" class="custom-file-input" id="customFile" name="select_file" data-allowed-file-extensions="csv" required/>
                            <label class="custom-file-label" for="customFile">Choose file</label>
                          </div>
                                                        
                        </div><br>
                 
                        <div class="col-md-12">
                            <hr>
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-xs"><?php echo e(__('keywords.Import Varients')); ?></button>
                          </div>
                        </div>
                </div>
            </div>
            
        </form>
    </div></div>

</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/product/bulkupload.blade.php ENDPATH**/ ?>