
<style>
   
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
              <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div>
             <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title"><?php echo e(__('keywords.Update Price/Mrp')); ?></h4>
                 </div>
                     <div class="container"> <br> 
                    <table id="datatableDefault" class="table text-nowrap w-100 table-striped">
                    <thead class="thead-light">
                            <tr>
                                <th class="text-center">#</th>
                                <th><?php echo e(__('keywords.Product')); ?> <?php echo e(__('keywords.Name')); ?></th>
                                <th><?php echo e(__('keywords.ID')); ?></th>
                                <th><?php echo e(__('keywords.Current Price/Mrp')); ?></th>
                                <th><?php echo e(__('keywords.Add Price/Mrp')); ?></th>
                                <th><?php echo e(__('keywords.Actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                             
                              <?php if(count($selected)>0): ?>
                      <?php $i=1; ?>
                      <?php $__currentLoopData = $selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($i); ?></td>
                        <td><p><?php echo e($sel->product_name); ?>(<?php echo e($sel->quantity); ?> <?php echo e($sel->unit); ?>)</p></td>
                        <td><b><?php echo e($sel->p_id); ?></b></td>
                        <td><b>price : </b><?php echo e($sel->price); ?><br>
                       <b>mrp : </b><?php echo e($sel->mrp); ?></td>
                        <td>
                            
                         <form class="forms-sample" action="<?php echo e(route('price_update', $sel->p_id)); ?>" method="post" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>

                          <div class="col-md-12">
                          <div class="col-md-12" style="float:left">
                             <div class="form-group">
                              <label class="bmd-label-floating"><?php echo e(__('keywords.MRP')); ?></label>
                              <input type="number" step="0.10" name="mrp" class="form-control" value="0">
                            </div>
                            <div class="form-group">
                              <label class="bmd-label-floating"><?php echo e(__('keywords.Price')); ?></label>
                              <input type="number" step="0.10" name="price" class="form-control" value="0">
                            </div>
                            <div class="form-group">
                             <button type="submit" class="btn btn-primary"> <i class="fa fa-plus"></i></button>
                             </div>
                          </div>
                        
                          </form>
                          </div>
                        </td>
                        <td class="td-actions text-right">
                           <a href="<?php echo e(route('delete_product', $sel->p_id)); ?>" rel="tooltip" class="btn btn-danger">
                                <i class="material-icons">close</i>
                            </a>
                        </td>
                    </tr>
                      <?php $i++; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                <tr>
                                  <td><?php echo e(__('keywords.No data found')); ?></td>
                                </tr>
                              <?php endif; ?>
                        </tbody>
                    </table>
                     <div class="pull-right mb-1" style="float: right;">
                      <?php echo e($selected->render("pagination::bootstrap-4")); ?>

                    </div>
                    </div>
                </div>
              </div>
            </div>
			</div>
          </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/store/products/product.blade.php ENDPATH**/ ?>