

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Order By Photo')); ?> <?php echo e(__('keywords.List')); ?></h4>
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100 table-striped">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th><?php echo e(__('keywords.User')); ?></th>
            <th><?php echo e(__('keywords.Address')); ?></th>
            <th><?php echo e(__('keywords.Accept/Reject')); ?></th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($list)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($user->name); ?><br>
           (<?php echo e($user->user_phone); ?>)</td>
           <td><?php echo e($user->receiver_name); ?>,<?php echo e($user->house_no); ?>,<?php echo e($user->landmark); ?>,<?php echo e($user->state); ?>,<?php echo e($user->pincode); ?></td>
            <td>
               <?php if($user->processed == 0): ?>
                 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($user->ord_id); ?>"><?php echo e(__('keywords.View & Accept')); ?></button>
           <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal2<?php echo e($user->ord_id); ?>"><?php echo e(__('keywords.Reject')); ?></button>
           <?php else: ?>
           <span style="color:green"><b><?php echo e(__('keywords.Accepted')); ?></b></span>
           <?php endif; ?>
            </td>
        </tr>
 <!--/////////Accept orders///////////-->        
<div class="modal fade" id="exampleModal1<?php echo e($user->ord_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<h5 class="modal-title" id="exampleModalLabel"><b><?php echo e(__('keywords.View & Accept')); ?></b></h5>
        					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        						<span aria-hidden="true">&times;</span>
        					</button>
        			</div>
        			<div class="container"> <br> 
                       <div class="col-lg-12 text-center" align="center">
                          <img src="<?php echo e(url($user->list_photo)); ?>" style="width:200 !important;"> 
                       </div><br>
                      <div class="col-lg-12 text-center" align="center">
                       <a href="<?php echo e(route('store_accept_order', $user->ord_id)); ?>"  class="btn btn-primary pull-center"><?php echo e(__('keywords.Accept Order')); ?></a>
                        </div><br>
                     </div>  
        		
        		</div>
        	</div>
        </div>
        
<!-----reject order with cause ------->
 <div class="modal fade" id="exampleModal2<?php echo e($user->ord_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('keywords.Reject')); ?> <?php echo e(__('keywords.Order')); ?></h5>
        					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        						<span aria-hidden="true">&times;</span>
        					</button>
        			</div>
        			<!--//form-->
        		<form class="forms-sample" action="<?php echo e(route('store_reject_orderbyphoto', $user->ord_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

        			<div class="row">
        			  <div class="col-md-3" align="center"></div>  
                      <div class="col-md-6" align="center">
                          <br>
                        <div class="form-group">
                           <label><?php echo e(__('keywords.Send Rejection Reason to User')); ?></label>    
        		     	   <textarea class="form-control" name="cause" row="5" required></textarea>
        			    </div>
        			<button type="submit" class="btn btn-primary pull-center"><?php echo e(__('keywords.Submit')); ?></button><br>
        			</div>
        			</div>
        			 <br> 
                    <div class="clearfix"></div>
        			</form>
        		
        		</div>
        	</div>
        </div>
        
        
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="4"><?php echo e(__('keywords.No data found')); ?></td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>  
</div>
</div>
</div>
</div>
<div>
    </div>
    <!--/////////reject orders///////////-->
 

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/store/order_by_photo/user_orderlist.blade.php ENDPATH**/ ?>