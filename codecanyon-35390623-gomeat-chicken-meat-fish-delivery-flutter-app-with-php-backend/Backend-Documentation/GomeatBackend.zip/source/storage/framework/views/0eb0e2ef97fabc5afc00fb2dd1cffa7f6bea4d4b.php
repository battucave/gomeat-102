<html>
    <body>
        <p>Delivery Completed: Order id #<?php echo e($cart_id); ?> contains of <?php echo e($prod_name); ?> of price <?php echo e($currency_sign); ?> <?php echo e($price2); ?> is Delivered Successfully.</p>
    </body>
</html><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/mail/del_comstore.blade.php ENDPATH**/ ?>