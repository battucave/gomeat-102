
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">

<style>
  
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
      
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title "><?php echo e(__('keywords.Store')); ?> <?php echo e(__('keywords.List')); ?></h4>
    </div>
<div class="container"> <br> 
<table id="datatableDefault" class="table text-nowrap w-100 table-striped">
    <thead class="thead-light">
        <tr>
            <th class="text-center">#</th>
                      <!--<th>ID</th>-->
                      <th><?php echo e(__('keywords.Store Name')); ?></th>
                      <th><?php echo e(__('keywords.City')); ?></th>
                      <th><?php echo e(__('keywords.Mobile')); ?></th>
                      <th><?php echo e(__('keywords.Email')); ?></th>
                      <th><?php echo e(__('keywords.Item Sale Report')); ?></th>
                    </thead>
                    <tbody>
                         <?php if(count($city)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i); ?></td>
                                <td><?php echo e($cities->store_name); ?></td>
                                <td><?php echo e($cities->city); ?></td>
                                <td><?php echo e($cities->phone_number); ?></td>
                                <td><?php echo e($cities->email); ?></td>
                                <td><a href="<?php echo e(route('req_items_today', $cities->id)); ?>" rel="tooltip">
                                <i class="material-icons" style="color:green">layers</i></a></td>
                                
                            </tr>      
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td colspan="6"><?php echo e(__('keywords.No data found')); ?></td>
                        </tr>
                      <?php endif; ?>  
                    </tbody>
</table>
<div class="pull-right mb-1" style="float: right;">
  <?php echo e($city->render("pagination::bootstrap-4")); ?>

</div>
</div>
</div>
</div>
</div>
</div>
<div>
    </div>

    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/itemsalesreport/stores.blade.php ENDPATH**/ ?>