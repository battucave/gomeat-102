<html>
    <body>
        <p>Welcome to Gogrocer family. We are Happy to have you here.</p><br>
        <h1>HAPPY SHOPPING !</h1>
    </body>
</html><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/mail/welmail.blade.php ENDPATH**/ ?>