<html>
    <body>
        <p>Out For Delivery: Your order id #<?php echo e($cart_id); ?> contains of <?php echo e($prod_name); ?> of price <?php echo e($currency_sign); ?> <?php echo e($price2); ?> is Out For Delivery.Get ready with <?php echo e($currency->currency_sign); ?> <?php echo e($rem_price); ?> cash.</p>
    </body>
</html><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/mail/coddel_out.blade.php ENDPATH**/ ?>