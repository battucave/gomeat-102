
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Invoice</title>
        <style>
 html {
    width: 180px;
}
  * {
    font-size: 12px;
    font-family: 'Times New Roman';
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
}

td.description,
th.description {
    width: 65px;
    max-width: 65px;
}

td.quantity,
th.quantity {
    width: 30px;
    max-width: 30px;
    word-break: break-all;
}

td.price,
th.price {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

.centered {
    text-align: center;
    align-content: center;
}



img {
    max-width: inherit;
    width: inherit;
}

@media  print {
    .hidden-print,
    .hidden-print * {
        display: none !important;
    }
}  </style>
    </head>
    <body>
        <div class="ticket" align="center">
              <img src="<?php echo e(url($logo->icon)); ?>" alt="app-logo" style="width:40px"/>
             <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%" data-background-color="purple">

                
                <tbody>
                    <tr>
                        <td colspan="5">
                            <table class="table">
                                <tr>
                                    <td valign="top" style="width:50%">
                                    <strong> <?php echo e(__('keywords.Order_Id')); ?> : </strong> <?php echo e($order->cart_id); ?>

                                    <br />
                                      <strong><?php echo e(__('keywords.Customer_name')); ?> : </strong><?php echo e($order->receiver_name); ?><br/>
                                        <strong><?php echo e(__('keywords.Contact')); ?> : </strong><?php echo e($order->receiver_phone); ?>, <?php if($order->user_phone != $order->receiver_phone): ?><?php echo e($order->receiver_phone); ?><?php endif; ?> <br/> 
                                    <strong>  <?php echo e(__('keywords.Delivery_Date')); ?> : </strong><?php echo e($order->delivery_date); ?>

                                    <br />
                                    <strong>  <?php echo e(__('keywords.Time_Slot')); ?> : </strong><?php echo e($order->time_slot); ?>

                                    <br />
                                    </td>
                                    <td  style="width:50%" align="right">
                                        <strong> <?php echo e(__('keywords.Delivery Address')); ?> </strong><br />
                                      
                                        <b><?php echo e($order->type); ?> :</b> <?php echo e($order->house_no); ?>,<?php echo e($order->society); ?>,<br><?php if($order->landmark !=NULL): ?> <?php echo e($order->landmark); ?>,<br><?php endif; ?> <?php echo e($order->city); ?>,<?php echo e($order->state); ?>,<br>
                                          <?php echo e($order->pincode); ?>

                                     </td>
                                    
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <th><?php echo e(__('keywords.Product_Name')); ?></th>
                        <th><?php echo e(__('keywords.Qty')); ?></th>
                        <th><?php echo e(__('keywords.Tax')); ?></th>
                        <th><?php echo e(__('keywords.Price')); ?></th>
                        <th><?php echo e(__('keywords.Total_Price')); ?></th>
                    </tr>
                    <?php if(count($details)>0): ?>
                            <?php $i=1; ?>
                                      
                          <tr>             
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                         <td><p><?php echo e($detailss->product_name); ?>(<?php echo e($detailss->quantity); ?><?php echo e($detailss->unit); ?>)</p>
                            </td>
                            <td><?php echo e($detailss->qty); ?></td>
                             <td> <?php if($detailss->tx_per == 0 || $detailss->tx_per == NULL): ?>0 <?php else: ?> <?php echo e($detailss->tx_per); ?><?php endif; ?> % <?php if($detailss->tx_per != 0 && $detailss->tx_name != NULL): ?>(<?php echo e($detailss->tx_name); ?>)<?php endif; ?></td>
                             <td>
                            <p><span style="color:grey"><?php if($detailss->price_without_tax != NULL): ?><?php echo e($detailss->price_without_tax); ?> <?php else: ?> <?php echo e($detailss->price); ?> <?php endif; ?></span></p>
                           </td>
                            <td> 
                            <p><span style="color:grey"><?php echo e($detailss->price); ?></span></p>
                           </td>
    		          
                         </tr>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                            <tr>
                              <td><?php echo e(__('keywords.No_data_found')); ?></td>
                            </tr>
                                  <?php endif; ?>
                   
                   
                    <tr>
                        <td colspan="4" class="text-right"><strong class="pull-right"><?php echo e(__('keywords.Products_Price')); ?> : </strong></td>
                         <td  class="text-right" colspan="1">
                            <strong><?php echo e($order->price_without_delivery); ?></strong>
                        </td>
                    </tr><tr>
                        <td colspan="4"  class="text-right"><strong class="pull-right"><?php echo e(__('keywords.Delivery_Charge')); ?> : </strong></td>
                         <td  class="text-right"  colspan="1">
                            <strong >+<?php echo e($order->delivery_charge); ?></strong>
                        </td>
                    </tr><?php if($order->paid_by_wallet > 0): ?>
                    <tr>    
                        <td colspan="4"  class="text-right"><strong class="pull-right"><?php echo e(__('keywords.Paid_By_Wallet')); ?> : </strong></td>
                         <td  class="text-right" colspan="1">
                            <strong>-<?php echo e($order->paid_by_wallet); ?></strong>
                        </td>
                    </tr><?php endif; ?>
                    <?php if($order->coupon_discount > 0): ?>
                    <tr>    
                        <td colspan="4" class="text-right"><strong class="pull-right"><?php echo e(__('keywords.Coupon_Discount')); ?> : </strong></td>
                         <td  class="text-right" colspan="1">
                            <strong class="">-<?php echo e($order->coupon_discount); ?></strong>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td colspan="4" class="text-right"><strong class="pull-right"><?php echo e(__('keywords.Net_Total(Payable)')); ?>:</strong></td>
                        <td  class="text-right" colspan="1"><?php echo e($order->rem_price); ?></td>
                    </tr>
                </tbody>
            </table>
            <p class="centered">Thanks for your purchase!
        </div>
        <button id="btnPrint" class="hidden-print">Print</button>
        <script>const $btnPrint = document.querySelector("#btnPrint");
$btnPrint.addEventListener("click", () => {
    window.print();
});</script>
    </body>
</html><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/invoice/invoice.blade.php ENDPATH**/ ?>