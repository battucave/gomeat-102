<!DOCTYPE html>
<html  lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="utf-8" />
	<title><?php echo e($logo->name); ?> Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="description" content="" />
	<meta name="author" content="" />
	
	<!-- ================== BEGIN core-css ================== -->
	<link href="<?php echo e(url('assets/theme_assets/css/app.min.css')); ?>" rel="stylesheet" />
	<!-- ================== END core-css ================== -->
	
</head>
<body>
	<!-- BEGIN #app -->
	<div id="app" class="app app-full-height app-without-header">
		<!-- BEGIN login -->
		<div class="login">
		    
			<!-- BEGIN login-content -->
			<div class="login-content">
			    <div  align="center">
			    	<img align="center" img style="width:100px;height:auto;" src="<?php echo e($url_aws.$logo->icon); ?>" alt="IMG">
			    	</div><hr>
			    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                        <?php if(is_array(session()->get('success'))): ?>
                                <ul>
                                    <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($message); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php else: ?>
                                    <?php echo e(session()->get('success')); ?>

                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                         <?php if(count($errors) > 0): ?>
                          <?php if($errors->any()): ?>
                            <div class="alert alert-danger" role="alert">
                              <?php echo e($errors->first()); ?>

                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                              </button>
                            </div>
                          <?php endif; ?>
                        <?php endif; ?>
				<form action="<?php echo e(route('adminLoginCheck')); ?>" method="POST" name="login_form">
				    <?php echo e(csrf_field()); ?>

					<h1 class="text-center"><?php echo e(__('keywords.Sign In')); ?></h1>
					<div class="text-muted text-center mb-4">
						<?php echo e(__('keywords.Admin/Sub-Admin Login.')); ?>

					</div>
					<div class="form-group">
						<label><?php echo e(__('keywords.Email Address')); ?></label>
						<input data-validate = "Valid email is required: ex@abc.xyz" type="email" class="form-control form-control-lg fs-15px" name="email" placeholder="username@address.com" />
					</div>
					<div class="form-group">
						<div class="d-flex">
							<label><?php echo e(__('keywords.Password')); ?></label>
							<a href="<?php echo e(route('reset_pass')); ?>" class="ml-auto text-muted"><?php echo e(__('keywords.Forgot password?')); ?></a>
						</div>
						<input type="password" class="form-control form-control-lg fs-15px" name="password" placeholder="Enter your password" />
						 <?php echo $__env->make('admin.partials._googletagmanager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
					<div class="form-group">
						<div class="custom-control custom-checkbox">
							<input class="custom-control-input" type="checkbox" value="" id="customCheck1" />
							<label class="custom-control-label fw-500" for="customCheck1"><?php echo e(__('keywords.Remember me')); ?></label>
						</div>
					</div>
					<button type="submit" class="btn btn-primary btn-lg btn-block fw-500 mb-3"><?php echo e(__('keywords.Sign In')); ?></button>
				</form>
			</div>
			<!-- END login-content -->
		</div>
		<!-- END login -->
		
		<!-- BEGIN btn-scroll-top -->
		<a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
		<!-- END btn-scroll-top -->
	</div>
	<!-- END #app -->
	
	<!-- ================== BEGIN core-js ================== -->
	<script src="<?php echo e(url('assets/theme_assets/js/app.min.js')); ?>"></script>
	<!-- ================== END core-js ================== -->
	
</body>
</html><?php /**PATH /home/u936827588/domains/thecodecafe.in/public_html/gogrocer_plus/source/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>