<div align="center">
    <h3 style="color:green">Your password is changed please login to your app with new password</h3>
</div>