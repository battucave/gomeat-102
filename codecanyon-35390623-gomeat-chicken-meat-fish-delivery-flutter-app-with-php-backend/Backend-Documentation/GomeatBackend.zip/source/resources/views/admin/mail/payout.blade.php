<html>
    <body>
        <p>Amount of {{$amt}} marked paid successfully to {{$store_name}} </p>
    </body>
</html>