<html>
    <body>
        <p> Order Successfully Placed: Your order id #{{$cart_id}} contains of {{$prod_name}} of price {{$currency_sign}} {{$price2}} is placed Successfully.You can expect your item(s) will be delivered on {{$delivery_date}} between {{$time_slot}}.</p>
    </body>
</html>