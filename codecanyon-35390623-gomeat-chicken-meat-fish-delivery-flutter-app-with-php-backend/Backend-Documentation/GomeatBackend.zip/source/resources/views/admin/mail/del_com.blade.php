<html>
    <body>
        <p>Delivery Completed: Your order id #{{$cart_id}} contains of {{$prod_name}} of price {{$currency_sign}} {{$price2}} is Delivered Successfully.</p>
    </body>
</html>