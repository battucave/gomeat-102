  <div id="app" class="app app-footer-fixed">
  <div id="footer" class="app-footer">
        {{$logo->footer_text}} (VERSION - 1.0.2)
  </div>
</div>