<footer class="footer">
<div class="container bottom_border">
<div class="row">
<div class=" col-sm-3 fot_mobileres">
<h5 class="headin5_amrc col_white_amrc pt2">Extras</h5>
<!--headin5_amrc-->
<ul class="footer_ul_amrc" style="margin-top: -10px;">
<li><a href="http://webenlance.com">Image Rectoucing</a></li>
<li><a href="http://webenlance.com">Clipping Path</a></li>
<li><a href="http://webenlance.com">Hollow Man Montage</a></li>
<li><a href="http://webenlance.com">Ebay & Amazon</a></li>
</ul>

<h5 class="headin5_amrc col_white_amrc">Customer Service</h5>
<!--headin5_amrc-->
<ul class="footer_ul_amrc">
<li><a href="http://webenlance.com">Image Rectoucing</a></li>
<li><a href="http://webenlance.com">Clipping Path</a></li>
<br>
</ul>
<!--footer_ul_amrc ends here-->
</div>


<div class=" col-sm-2 fot_mobileres" style="border-right: 1px solid #484848">
<h5 class="headin5_amrc col_white_amrc pt2">Need Help?</h5>
<!--headin5_amrc-->
<ul class="footer_ul_amrc" style="margin-top: -10px;">
<li><a href="http://webenlance.com">Image Rectoucing</a></li>
<li><a href="http://webenlance.com">Clipping Path</a></li>
<li><a href="http://webenlance.com">Hollow Man Montage</a></li>
<li><a href="http://webenlance.com">Ebay & Amazon</a></li>
<li><a href="http://webenlance.com">Hair Masking/Clipping</a></li>
</ul>
<!--footer_ul_amrc ends here-->
</div>


<div class="col-sm-4 fott_join">
<h5 class="headin5_amrc col_white_amrc pt2">Join lorem dummy</h5>


<button class="btn fott_become">Become A Seller</button>


<button class="btn fott_register">Register As Delivery Staff</button>



</div>


<div class=" col-sm-4 col-md  col-12 col mob_social" style="padding-left: 55px;">
<h5 class="headin5_amrc col_white_amrc pt2">Connect With Us
</h5>
<!--headin5_amrc ends here-->

<ul class="footer_ul2_amrc">
<li><img src="image/fa.PNG" height="28" style="margin-left: 10px;"><img src="image/tw.PNG" height="28" style="margin-left: 18px;"><img src="image/ins.PNG" height="28" style="margin-left: 18px;"> <img src="image/yu.PNG" height="28" style="margin-left: 18px;"></li>

</ul>


<h5 class="headin5_amrc col_white_amrc pt2">Payment Options

</h5>
<!--headin5_amrc ends here-->

<ul class="footer_ul2_amrc">
<li><img src="image/p_card_1.PNG" height="28" style="margin-left: 11px;"><img src="image/p_card_1.PNG" height="28" style="margin-left: 10px;"><img src="image/p_card_1.PNG" height="28" style="margin-left: 10px;"> <img src="image/p_card_1.PNG" height="28" style="margin-left: 10px;"></li>

</ul>
<!--footer_ul2_amrc ends here-->
</div>
</div>
</div>

<hr class="fott_hr">


<div class="container">
	<h5 class="headin5_amrc col_white_amrc">Currently we are serving in following cities only:
</h5>

<p style="margin-top: 25px;">
<span class="main_city">Chandigarh, Punjab, India</span> 
<span class="main_city">Chandigarh, Punjab, India</span>
<span class="main_city">Chandigarh, Punjab, India</span>
<span class="main_city">Chandigarh, Punjab, India</span>
 </p>

</div>

<hr class="fott_hr4">

<h6  id="bot_footer23"><span>Copyright © 2020 Lorem (lorem) Developed by dummy content.

</span><span style="float: right;">
Privacy Policy | Terms & Conditions | Sitemap</span></h6>

</footer>